import React from 'react'
import BusinessSetupIntro from '@/components/Bussiness_Setup/BusinessSetupIntro'
const page = () => {
  return (
    <div>
      <BusinessSetupIntro />
    </div>
  )
}

export default page
