import React from 'react'
import AuthForms from '@/components/AuthForms'
const page = () => {
  return (
    <div>
      <AuthForms />
    </div>
  )
}

export default page
