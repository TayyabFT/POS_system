import LandingPage from '@/components/LandingPage'
import React from 'react'

const page = () => {
  return (
    <div>
      <LandingPage/>
    </div>
  )
}

export default page;